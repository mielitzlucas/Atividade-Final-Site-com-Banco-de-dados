<?php
include('conexao_carrinho.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo '<pre>';
    print_r($_POST); 
    echo '</pre>';

    $quanitdade = isset($_POST['quantidade']) ? $_POST['quantidade'] : null;
    $preço = isset($_POST['preço']) ? $_POST['preço'] : null;
    $produto = isset($_POST['produto']) ? $_POST['produto'] : null;


    if (empty($quanitdade) || empty($preço) || empty($produto)) {
        die("Por favor, preencha todos os campos.");
    }

    // Prepara o comando SQL para inserir os dados no banco
    $sql = "INSERT INTO usuarios (nome, email, mensagem) 
            VALUES ('$quanitdade', '$preço', '$produto')";

    if ($conexao->query($sql) === TRUE) {
        echo "Mensagem enviada com sucesso!";
    } else {
        echo "Erro ao enviar mensagem: " . $conexao->error;
    }

    $conexao->close();
}
?>
