<?php
$servidor = "localhost";  // Endereço do servidor
$usuario = "root";        // Usuário padrão
$senha = "";              // Senha padrão (vazia no XAMPP)
$banco = "meu_banco";     // Nome do banco de dados
$porta = 4306;            // Porta personalizada do MySQL

// Criar conexão
$conexao = new mysqli($servidor, $usuario, $senha, $banco, $porta);

// Verificar conexão
if ($conexao->connect_error) {
    die("Erro ao conectar ao banco de dados: " . $conexao->connect_error);
}
?>
