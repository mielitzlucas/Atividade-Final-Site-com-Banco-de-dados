<?php
// Inclui a conexão com o banco de dados
include('conexao.php');

// Verifica se o formulário foi enviado via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Debug: Mostra os dados enviados
    echo '<pre>';
    print_r($_POST); // Verifica os dados enviados
    echo '</pre>';

    // Recebe os dados do formulário
    $nome = isset($_POST['nome']) ? $_POST['nome'] : null;
    $email = isset($_POST['email']) ? $_POST['email'] : null;
    $mensagem = isset($_POST['mensagem']) ? $_POST['mensagem'] : null;

    // Validar se os campos não estão vazios
    if (empty($nome) || empty($email) || empty($mensagem)) {
        die("Por favor, preencha todos os campos.");
    }

    // Prepara o comando SQL para inserir os dados no banco
    $sql = "INSERT INTO usuarios (nome, email, mensagem) 
            VALUES ('$nome', '$email', '$mensagem')";

    // Executa a consulta no banco de dados
    if ($conexao->query($sql) === TRUE) {
        echo "Mensagem enviada com sucesso!";
    } else {
        echo "Erro ao enviar mensagem: " . $conexao->error;
    }

    // Fecha a conexão com o banco
    $conexao->close();
}
?>
