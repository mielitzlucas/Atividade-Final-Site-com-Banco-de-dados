<?php
include('conexao_carrinho.php'); // Conecta ao banco

$sql = "SELECT * FROM compras";
$resultado = $conexao->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Compras</title>
</head>
<body>
    <h1>Lista de compras</h1>
    <table border="1">
        <tr>
            <th>id</th>
            <th>quanntidade</th>
            <th>preço</th>
            <th>produto</th>
        </tr>
        <?php
        if ($resultado->num_rows > 0) {
            while ($linha = $resultado->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $linha['id'] . "</td>";
                echo "<td>" . $linha['quantidade'] . "</td>";
                echo "<td>" . $linha['preço'] . "</td>";
                echo "<td>" . $linha['produto'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='3'>Nenhum dado encontrado</td></tr>";
        }
        ?>
    </table>
</body>
</html>
